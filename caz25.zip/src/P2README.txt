 Project 2
 Name: Christopher Zawora	 
 E-mail: caz25@georgetown.edu 
 Instructor: Singh 
 COSC 150 
 
 
 README
 
 
 In order to run the program, unzip the files and open them on Eclipse. This 
 program was created on Eclipse Platform version 4.3.1.v20130911-1000. This program
 will create a new window in which the brickbreaker game begins to play. The main function
 is located in the Breakout class. Three test classes exist that test 6
 essential functions for detecting collisions with blocks and the wall and slider. 
 They also test if the blocks are created properly.
 
 Because I found the game took a while become visible on my computer I had the ball start 
 by moving upwards instead of downwards. This prevented the user from losing before s/he 
 could even see the game.
 
 There are no known problems with the code.
 
 Additionally, the program has the added features:
 	allowing the user to change the ball speed.
 	different blocks take different amounts of hits to break.
 	a timer that keeps track of how long the player has been playing the game.
 	